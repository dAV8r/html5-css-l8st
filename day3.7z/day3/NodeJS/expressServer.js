var express=require('express');

app = express();

app.get("/",(req,res)=>{
    res.send("hello World");
})
app.listen(3000,()=>{
    console.log("Server listening on port 3000");
})