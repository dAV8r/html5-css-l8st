function abc(){
    console.log("hello")
}

abc();