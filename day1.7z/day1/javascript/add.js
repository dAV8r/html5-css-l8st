function addNums(){
    var num1 = document.getElementById("number1").value;
    var num2 = document.getElementById("number2").value;
    console.log("num1:"+num1)
    console.log("num2:"+num2)
    document.getElementById("result").value = parseFloat(num1)+parseFloat(num2);
    // or
    // var a = document.forms["f1"]["n1"].value;
    // where f1 is the form name and n1 is the name of the input box
    // or
    // var a= document.forms.f1.n1.value;
}