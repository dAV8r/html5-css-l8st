var canvas = document.querySelector("canvas");
var c = canvas.getContext('2d');
c.fillStyle='red';
c.fillRect(10,10,100,100);
c.fillStyle='black';
c.fillRect(50,60,100,50);

c.beginPath();
c.moveTo(0,0);
c.lineTo(150,150);
c.strokeStyle = "yellow"
c.stroke();