var g=100
function myFunction(){
    document.getElementById("demo").innerHTML = "OK";
    console.log("parachange")
};

function changeHead(){
    var a=10;  //removing var will make the variable global
    var b=20;
    var isChanged = true
    document.querySelector("h1").innerHTML = "Congratulations! You won!";
    console.log("headchange "+(a+b)+" "+isChanged);
    console.log(g)
    // .getElementByTagName("h1").innerHTML = 
};

(function (){  //example of IIFE functions  
    console.log("DEMO");
})()